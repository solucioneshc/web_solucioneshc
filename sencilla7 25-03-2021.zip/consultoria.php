<?php
include 'plantilla/cabecera.php'
?>



<!-- PIE DE PAGINA  -->
<?php
include 'plantilla/pie.php'
?>
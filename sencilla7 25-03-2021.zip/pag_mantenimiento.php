<?php
include 'plantilla/cabecera.php'
?>

<div class="row">
    <div class=" col-12 mantenimiento">
       <h1>Estamos trabajando para tener listo el sitio web pronto.</h1>
        <p>Nuestro desarrollador Hector Cañongo, está haciendo su mayor esfuerzo para finalizar el sitio
            web antes que este conteo termine. Favor, ten algo de paciencia. </p>

    </div>
    <div class="col-12 man_imagen" >
        <img src="imagenes/mantenimiento/pagina_construccion.png" alt="">
    </div>

</div>


<!-- PIE DE PAGINA  -->
<?php
include 'plantilla/pie.php'
?>
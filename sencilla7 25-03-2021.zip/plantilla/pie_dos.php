<div class="row mt-3" id="pie_principal">
    <div class="col-md-3 col-sm-6 col-xs-12 mt-4">
        <p id="pie_pagina">Busca un Distribuidor</p>
    </div>
    <div class="col-md-3 col-sm-6 col-xs-12 mt-4">
        <p id="pie_pagina">Compra Online</p>

        <ul><a href=""> Tienda en Linea</a></ul>
        <ul><a href=""> Libro de Reclamaciones</a></ul>
        <ul><a href=""> Políticas y Privacidad en Linea</a></ul>
        <ul><a href=""> Términos y Condiciones</a></ul>



    </div>
    <div class="col-md-3 col-sm-12 col-xs-12 mt-4">
        <p id="pie_pagina">Comunidad</p>
        <ul><a href=""> Comunidad Alfa</a></ul>
        <ul><a href=""> Blog</a></ul>
        <ul><a href=""> Ayuda con mi Producto</a></ul>


    </div>
    <div class="col-md-3 col-sm-12 col-xs-12 mt-4">
        <p id="pie_pagina">Noticias e Información</p>
        <ul><a href=""> Información Corporativa</a></ul>
        <ul><a href=""> Centro de Prensa</a></ul>


    </div>
</div>

<div class="row" id="pie_principal">
    <div class="col-6">

    </div>
    <div class="col-6">
        <p id="pie_pagina"> Productos y soluciones profesionales contacto
        <button type="submit">
            <ion-icon name="logo-facebook"></ion-icon>
        </button>
        <button type="submit">
        <ion-icon name="logo-instagram"></ion-icon>
        </button>
        <button type="submit">
        <ion-icon name="logo-youtube"></ion-icon>
        </button>
        <button type="submit">
        <ion-icon name="egg-outline"></ion-icon>
        </button>

    </div>
    <hr>
</div>

<div class="row" id="pie_principal">
    <div class="col-12" id="pie_pagina">
        <p> Política de privacidad @2020, todos los derechos reservados</p>
        
        <p>pagina de prueba</p>
    </div>
</div>

</div>



</body>

<!-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> -->

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>


<script src="js/main.js"></script>


<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
</script>
<script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>

</html>
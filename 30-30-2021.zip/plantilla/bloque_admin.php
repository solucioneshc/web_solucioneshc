
<div class="col-3" id="fondo_carrito">

    
        <ul class="menu">
        <li>
                <a  href="../administrativo/inicio1.php">INICIO</a>
                
            </li>
            <li>
                <a  href="#">USUARIOS</a>
                <ul>
                    <li><a href="../administrativo/admin.php">Registro de usuario</a></li>
                    <li><a href="../administrativo/usuart_regis.php">consulta de usuarios</a></li>
                    <li><a href=""></a></li>
                </ul>
            </li>
            <li >
                <a  href="#">PRODUCTOS</a>
                <ul>
                    <li><a href="../administrativo/produc_regist.php">registro de usuario</a></li>
                    <li><a href="">consulta de productos</a></li>
                    <li><a href="">modificacion</a></li>
                </ul>
            </li>
            <li >
                <a  href="#">ARCHIVOS DE DESCARGAR GRATIS</a>
                <ul>
                    <li><a href="../administrativo/regist_descargas.php">registro de descargas</a></li>
                    
                </ul>
            </li>
            <li >
                <a  href="#">BASE DE DATOS EMPRESAS</a>
                <ul>
                    <li><a href="../administrativo/regist_empresa.php">registro de empresas</a></li>
                    <li><a href="../administrativo/empresa_regis.php">consulta de empresas</a></li>
                    
                </ul>
            </li>
            <li >
                <a  href="#"></a>
                <ul>
                    <li><a href="produc_regist.php">registro de usuario</a></li>
                    <li><a href=""></a></li>
                    <li><a href=""></a></li>
                </ul>
            </li>
            <li >
                <a  href="#"></a>
                <ul>
                    <li><a href="">registro de usuario</a></li>
                    <li><a href=""></a></li>
                    <li><a href=""></a></li>
                </ul>
            </li>
            
        </ul>
   

    <br>

</div>


<?php
include 'plantilla/cabecera.php'
?>

<div class="row mt-3" id="fondo1">
    <div class="col-md-6 col-sm-6 col-xs-12">

        <div class="jumbotron mt-3">
            <h1 class="display-4">Quienes Somos</h1>
            <p class="lead">Somos una empresa dedicada al area de tecnología en diferentes area, tenemos en el area
                mas de 18 años ofreciendo a nuestros clientes calidad de servicio.</p>
            <hr class="my-4">
            <p></p>
            <a class="btn btn-primary btn-lg" href="nosotros.php" role="button">misión</a>
            <a class="btn btn-primary btn-lg" href="vision.php" role="button">vision</a>
        </div>


    </div>
    <div class="col-md-6 col-sm-6 col-xs-12 mt-3">
        <h2>Visión</h2>
        <p>Ser una empresa que ayude aportar conocimientos para el uso de la tecnología, que las empresas puedan darle
            el 100% del beneficio y uso a los equipos informáticos </p>


    </div>
</div>

<?php
include 'plantilla/pie.php'
?>